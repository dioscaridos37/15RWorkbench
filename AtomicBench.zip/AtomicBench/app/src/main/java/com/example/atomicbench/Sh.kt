package com.example.atomicbench

import android.content.Context
import rikka.shizuku.Shizuku

object Sh {
    /** Команда с правами shell через Shizuku. Только не из главного потока. */
    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) {
        "ERR: ${e.message}"
    }

    fun async(cmd: String, ctx: Context? = null) = Thread {
        val r = run(cmd)
        ctx?.getSharedPreferences("wb", Context.MODE_PRIVATE)?.edit()?.putString("log", r.take(1500))?.apply()
    }.start()
}
