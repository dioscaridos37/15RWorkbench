package com.example.atomicbench

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { render() } }
    private val prefs by lazy { getSharedPreferences("wb", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 100, 40, 60) }
        sv.addView(root); setContentView(sv)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onDestroy() { Shizuku.removeRequestPermissionResultListener(permListener); super.onDestroy() }
    override fun onResume() { super.onResume(); render() }

    private fun shizukuRunning() = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    private fun shizukuGranted() = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun startSvc(action: String? = null) {
        val i = Intent(this, WorkbenchService::class.java)
        if (action != null) i.action = action
        startForegroundService(i)
    }

    private fun render() {
        root.removeAllViews()
        val run = shizukuRunning(); val ok = run && shizukuGranted()
        val overlay = Settings.canDrawOverlays(this)
        val side = prefs.getString("side", "left")
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "Shizuku запущен: ${if (run) "✅" else "❌"}\nДоступ Shizuku: ${if (ok) "✅" else "❌"}\n" +
                "Поверх других окон: ${if (overlay) "✅" else "❌"}\nКрай экрана: ${if (side == "right") "правый" else "левый"}"
        })
        if (run && !ok) root.addView(btn("1. Разрешить Shizuku") { Shizuku.requestPermission(1) })
        if (!overlay) root.addView(btn("2. Разрешить «Поверх других окон»") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("3. Включить оконный режим (freeform)") {
            Sh.async("settings put global enable_freeform_support 1; settings put global force_resizable_activities 1; " +
                "settings put global freeform_window_management 1; settings put global enable_non_resizable_multi_window 1; echo done", this)
            Toast.makeText(this, "Готово. Если окна не заработают, перезагрузите телефон.", Toast.LENGTH_LONG).show()
        })
        root.addView(btn("Край: левый") { prefs.edit().putString("side", "left").apply(); stopService(Intent(this, WorkbenchService::class.java)); render() })
        root.addView(btn("Край: правый") { prefs.edit().putString("side", "right").apply(); stopService(Intent(this, WorkbenchService::class.java)); render() })
        root.addView(btn("▶ Включить Workbench") {
            if (!ok || !overlay) Toast.makeText(this, "Сначала выполните шаги 1–3", Toast.LENGTH_LONG).show()
            else { startSvc(); Toast.makeText(this, "Свайпните от края экрана", Toast.LENGTH_LONG).show() }
        })
        root.addView(btn("Показать панель сейчас") { startSvc(WorkbenchService.ACTION_TOGGLE) })
        root.addView(btn("■ Выключить") { stopService(Intent(this, WorkbenchService::class.java)) })
        root.addView(btn("Обновить журнал") { render() })
        root.addView(TextView(this).apply {
            textSize = 11f
            text = "\nЖурнал:\n" + prefs.getString("log", "—")
        })
    }
}
