package com.example.atomicbench

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * Аналог Atomic Workbench:
 *  - свайп от края экрана выдвигает стеклянную панель (liquid glass + blur),
 *  - в панели автоматически недавние приложения: сверху текущее (главное), ниже ещё до 4,
 *  - нажатие на карточку открывает приложение в плавающем окне,
 *  - все движения на пружинах.
 */
class WorkbenchService : Service() {

    companion object {
        const val ACTION_TOGGLE = "toggle"
        const val ACTION_STOP = "stop"
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())

    private var panelRoot: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var glassBox: LinearLayout? = null

    private var side = 1                 // 1 = левый край, -1 = правый
    private var panelW = 0
    private var closedX = 0f
    private var openX = 0f
    private var curX = 0f
    private var isOpen = false
    private var ready = false
    private var blurOk = false
    private var anim: SpringAnimation? = null
    private var recents: List<String> = emptyList()

    private var tracker: VelocityTracker? = null
    private var downX = 0f
    private var dragging = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!ready) { setup(); ready = true }
        if (intent?.action == ACTION_TOGGLE) {
            if (isOpen) close() else { refresh(); open() }
        }
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("wb", "Workbench", NotificationManager.IMPORTANCE_MIN))
        fun pi(a: String) = PendingIntent.getService(
            this, a.hashCode(), Intent(this, WorkbenchService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "wb")
            .setContentTitle("Atomic Bench")
            .setContentText("Свайп от края экрана открывает панель")
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Открыть", pi(ACTION_TOGGLE)).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Выключить", pi(ACTION_STOP)).build())
            .build()
        startForeground(1, n)
    }

    // ---------- создание окон ----------

    private fun setup() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        side = if (getSharedPreferences("wb", MODE_PRIVATE).getString("side", "left") == "right") -1 else 1
        panelW = dp(88)
        closedX = -(panelW + dp(16)).toFloat()
        openX = dp(10).toFloat()
        curX = closedX
        blurOk = Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled
        buildPanel()
        buildTrigger()
        render()
    }

    private fun edgeGravity() = (if (side == 1) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL

    private fun buildPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = glass(dp(28).toFloat(), true)
        }
        glassBox = box
        val root = FrameLayout(this).apply {
            addView(box, FrameLayout.LayoutParams(panelW, ViewGroup.LayoutParams.WRAP_CONTENT))
            visibility = View.GONE
            alpha = 0f
        }
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && isOpen) close()
            false
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = edgeGravity()
        lp.x = closedX.toInt()
        if (blurOk) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 0
        }
        panelRoot = root
        panelLp = lp
        wm.addView(root, lp)
    }

    private fun buildTrigger() {
        val fl = FrameLayout(this)
        val pill = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.argb(150, 255, 255, 255)); cornerRadius = dp(2).toFloat()
            }
        }
        fl.addView(pill, FrameLayout.LayoutParams(dp(4), dp(64), edgeGravity()).apply {
            if (side == 1) leftMargin = dp(2) else rightMargin = dp(2)
        })
        val lp = WindowManager.LayoutParams(
            dp(26), dp(200),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = edgeGravity()

        fl.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; dragging = false
                    tracker?.recycle(); tracker = VelocityTracker.obtain(); tracker?.addMovement(e)
                    if (!isOpen) refresh()
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(e)
                    if (!isOpen) {
                        val d = (e.rawX - downX) * side
                        if (!dragging && d > dp(8)) {
                            dragging = true
                            anim?.cancel()
                            panelRoot?.visibility = View.VISIBLE
                            fl.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            playIn()
                        }
                        if (dragging) setPanelPos(closedX + rubber(d))
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    tracker?.addMovement(e)
                    if (isOpen) {
                        close()
                    } else if (dragging) {
                        tracker?.computeCurrentVelocity(1000)
                        val vx = (tracker?.xVelocity ?: 0f) * side
                        val d = (e.rawX - downX) * side
                        if (d > (openX - closedX) * 0.35f || vx > 700f) {
                            isOpen = true
                            springTo(openX, vx)
                        } else {
                            isOpen = false
                            springTo(closedX, vx) { if (!isOpen) panelRoot?.visibility = View.GONE }
                        }
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        open()
                    }
                    tracker?.recycle(); tracker = null
                }
            }
            true
        }
        if (Build.VERSION.SDK_INT >= 29) {
            fl.post { fl.systemGestureExclusionRects = listOf(Rect(0, 0, fl.width, fl.height)) }
        }
        triggerView = fl
        wm.addView(fl, lp)
    }

    private var triggerView: FrameLayout? = null

    private fun rubber(d: Float): Float {
        val dist = openX - closedX
        return if (d <= dist) d else dist + (d - dist) * 0.25f
    }

    // ---------- движение панели на пружинах ----------

    private fun setPanelPos(x: Float) {
        curX = x
        val lp = panelLp ?: return
        val root = panelRoot ?: return
        lp.x = x.toInt()
        val p = ((x - closedX) / (openX - closedX)).coerceIn(0f, 1f)
        root.alpha = p
        if (blurOk) lp.blurBehindRadius = (60 * p).toInt()
        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
    }

    private fun springTo(target: Float, velocity: Float, end: () -> Unit = {}) {
        anim?.cancel()
        val a = SpringAnimation(FloatValueHolder(curX))
        a.spring = SpringForce(target).setStiffness(380f).setDampingRatio(0.62f)
        a.setStartVelocity(velocity)
        a.addUpdateListener { _, v, _ -> setPanelPos(v) }
        a.addEndListener { _, canceled, _, _ -> if (!canceled) end() }
        anim = a
        a.start()
    }

    private fun open() {
        isOpen = true
        panelRoot?.visibility = View.VISIBLE
        playIn()
        springTo(openX, 0f)
    }

    private fun close() {
        isOpen = false
        springTo(closedX, 0f) { if (!isOpen) panelRoot?.visibility = View.GONE }
    }

    private fun springProp(v: View, p: DynamicAnimation.ViewProperty, to: Float, stiff: Float = 320f, damp: Float = 0.55f) {
        val a = SpringAnimation(v, p, to)
        a.spring.setStiffness(stiff).setDampingRatio(damp)
        a.start()
    }

    private fun playIn() {
        val box = glassBox ?: return
        for (i in 0 until box.childCount) {
            val v = box.getChildAt(i)
            v.alpha = 0f; v.scaleX = 0.55f; v.scaleY = 0.55f
            v.translationX = -side * dp(26).toFloat()
            ui.postDelayed({
                v.animate().alpha(1f).setDuration(140).start()
                springProp(v, DynamicAnimation.SCALE_X, 1f)
                springProp(v, DynamicAnimation.SCALE_Y, 1f)
                springProp(v, DynamicAnimation.TRANSLATION_X, 0f)
            }, 40L * i)
        }
    }

    // ---------- стекло ----------

    private fun glass(r: Float, strong: Boolean): Drawable {
        val tint = GradientDrawable().apply {
            cornerRadius = r
            setColor(Color.argb(if (blurOk) 55 else 135, 20, 24, 40))
        }
        val sheen = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(
                Color.argb(if (strong) 120 else 80, 255, 255, 255),
                Color.argb(22, 255, 255, 255),
                Color.argb(if (strong) 70 else 45, 190, 220, 255)
            )
        ).apply {
            cornerRadius = r
            setStroke(dp(1), Color.argb(if (strong) 190 else 120, 255, 255, 255))
        }
        return LayerDrawable(arrayOf(tint, sheen))
    }

    // ---------- карточки ----------

    private fun render() {
        val box = glassBox ?: return
        box.removeAllViews()
        if (recents.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "Откройте\nприложения"; setTextColor(Color.WHITE); textSize = 11f; gravity = Gravity.CENTER
            })
            return
        }
        recents.forEachIndexed { i, pkg ->
            val big = i == 0
            val size = dp(if (big) 68 else 60)
            val iconSize = dp(if (big) 46 else 40)
            val card = FrameLayout(this)
            card.background = glass(dp(20).toFloat(), big)
            val icon = ImageView(this)
            try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {}
            card.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER))
            card.layoutParams = LinearLayout.LayoutParams(size, size).apply { setMargins(0, dp(6), 0, dp(6)) }
            card.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        springProp(v, DynamicAnimation.SCALE_X, 0.86f, 700f, 0.7f)
                        springProp(v, DynamicAnimation.SCALE_Y, 0.86f, 700f, 0.7f)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        springProp(v, DynamicAnimation.SCALE_X, 1f, 400f, 0.45f)
                        springProp(v, DynamicAnimation.SCALE_Y, 1f, 400f, 0.45f)
                    }
                }
                false
            }
            card.setOnClickListener { launchWindow(pkg); close() }
            box.addView(card)
        }
    }

    // ---------- подхват недавних приложений ----------

    private fun refresh() {
        Thread {
            val out = Sh.run("dumpsys activity recents")
            val list = parseRecents(out)
            getSharedPreferences("wb", MODE_PRIVATE).edit()
                .putString("log", "недавние: $list" + if (list.isEmpty()) "\n" + out.take(600) else "").apply()
            ui.post {
                if (list != recents) {
                    recents = list
                    render()
                    if (panelRoot?.visibility == View.VISIBLE) playIn()
                }
            }
        }.start()
    }

    private fun parseRecents(out: String): List<String> {
        val re = Regex("A=\\d+:([A-Za-z0-9_.]+)")
        val res = LinkedHashSet<String>()
        for (line in out.lineSequence()) {
            if (!line.contains("Recent #")) continue
            if (line.contains("type=") && !line.contains("type=standard")) continue
            val pkg = re.find(line)?.groupValues?.get(1) ?: continue
            if (pkg == packageName || pkg == "com.android.systemui") continue
            if (packageManager.getLaunchIntentForPackage(pkg) == null) continue
            res.add(pkg)
            if (res.size >= 5) break
        }
        return res.toList()
    }

    // ---------- запуск в окне ----------

    private fun launchWindow(pkg: String) {
        val comp = packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString() ?: return
        val dm = resources.displayMetrics
        val l = dp(10); val t = dp(40)
        val r = dm.widthPixels - dp(10); val b = dm.heightPixels - dp(30)
        val script = """
            am start --windowingMode 5 -n $comp
            sleep 0.8
            ID=${'$'}(dumpsys activity activities | grep -E "Task\{.*A=[0-9]+:$pkg[ }]" | head -1 | sed -E 's/.*#([0-9]+) .*/\1/')
            echo "task=${'$'}ID"
            cmd activity task resize ${'$'}ID $l $t $r $b || am task resize ${'$'}ID $l $t $r $b
        """.trimIndent()
        Sh.async(script, this)
    }

    override fun onDestroy() {
        anim?.cancel()
        panelRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        triggerView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelRoot = null; triggerView = null
        super.onDestroy()
    }
}
